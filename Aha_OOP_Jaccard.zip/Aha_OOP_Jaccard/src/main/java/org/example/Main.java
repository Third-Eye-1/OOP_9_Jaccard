package org.example;

import java.io.IOException;

public class Main {
    public static void main(String[] args) {
        try {
            WordProcessor wordProcessor1 = new WordProcessor();
            wordProcessor1.readFile("C:\\Users\\user\\Downloads\\Assigment_9_java_OOp-master\\file1.txt");

            WordProcessor wordProcessor2 = new WordProcessor();
            wordProcessor2.readFile("C:\\Users\\user\\Downloads\\Assigment_9_java_OOp-master\\file2.txt");

            SimilarityCalculator similarityCalculator = new SimilarityCalculator();
            double similarity = similarityCalculator.calculateSimilarity(wordProcessor1.getDistinctWords(), wordProcessor2.getDistinctWords());

            System.out.println("Jaccard Similarity Coefficient: " + similarity);
            System.out.println(wordProcessor1.getDistinctWords());

        } catch (IOException e) {
            System.err.println("An error occurred while processing the files: " + e.getMessage());
        }
    }
}